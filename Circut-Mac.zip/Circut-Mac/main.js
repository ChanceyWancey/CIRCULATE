const { app, BrowserWindow, BrowserView, ipcMain, session, shell, dialog, net, screen } = require("electron");
const path = require("path");
const fs = require("fs");
const https = require("https");
const http = require("http");
const { execFile } = require("child_process");

let win;
let tabs = [];
let activeTab = 0;
let bookmarks = [];
let history = [];

// --- Extensions state ---
let extensionsConfig = [];       // [{ path, enabled }] persisted to disk
const popupWindows = new Map();  // extensionId -> BrowserWindow (open action popups)

// --- Proxy / "VPN" state ---
// mode: "direct" | "system" | "fixed" | "pac"
let proxyConfig = { mode: "direct", rules: "", pac: "", bypass: "<local>", username: "", password: "" };
let lastProxyAuthFailed = false;
// The web page is a native layer that always draws above our HTML toolbar/panel,
// so we keep it explicitly out of that space rather than relying on CSS z-index.
let toolbarHeight = 92; // sane fallback until the renderer reports the real value
let panelWidth = 0;
let panelOpen = false;

// session.loadExtension/removeExtension/getAllExtensions are deprecated in
// favor of session.extensions.* (added Electron 32). Fall back gracefully
// in case this ever runs on an older Electron.
const extAPI = () => session.defaultSession.extensions || session.defaultSession;

const dataDir = () => app.getPath("userData");
const bookmarksFile = () => path.join(dataDir(), "bookmarks.json");
const historyFile = () => path.join(dataDir(), "history.json");
const extensionsFile = () => path.join(dataDir(), "extensions.json");
const proxyFile = () => path.join(dataDir(), "proxy.json");

function saveProxyConfig() {
  try { fs.writeFileSync(proxyFile(), JSON.stringify(proxyConfig, null, 2)); } catch {}
}

// Translate our config into the shape session.setProxy expects, then flush the
// connection pool — Chromium keeps existing sockets alive, so without this the
// current tab keeps using the old route until something forces a reconnect.
async function applyProxy() {
  const ses = session.defaultSession;
  let options;
  if (proxyConfig.mode === "fixed") {
    options = { proxyRules: proxyConfig.rules, proxyBypassRules: proxyConfig.bypass || "" };
  } else if (proxyConfig.mode === "pac") {
    options = { mode: "pac_script", pacScript: proxyConfig.pac, proxyBypassRules: proxyConfig.bypass || "" };
  } else if (proxyConfig.mode === "system") {
    options = { mode: "system" };
  } else {
    options = { mode: "direct" };
  }

  await ses.setProxy(options);
  lastProxyAuthFailed = false;
  try { await ses.closeAllConnections(); } catch {}
}

function loadData() {
  try { bookmarks = JSON.parse(fs.readFileSync(bookmarksFile(), "utf8")); } catch {}
  try { history = JSON.parse(fs.readFileSync(historyFile(), "utf8")); } catch {}
  try {
    proxyConfig = Object.assign(proxyConfig, JSON.parse(fs.readFileSync(proxyFile(), "utf8")));
  } catch {}
}

function saveExtensionsConfig() {
  try { fs.writeFileSync(extensionsFile(), JSON.stringify(extensionsConfig, null, 2)); } catch {}
}

function readManifest(extPath) {
  try {
    return JSON.parse(fs.readFileSync(path.join(extPath, "manifest.json"), "utf8"));
  } catch {
    return null;
  }
}

// Electron has a known bug (electron/electron#41613, fixed in v42+; we're on
// 38) where an MV3 extension's background service worker starts the very
// first time it's loaded, but never again on later app launches. Nothing
// crashes — the worker just silently never boots, so every
// chrome.runtime.sendMessage to it hangs forever with no error anywhere.
//
// Electron's own documented workaround is to explicitly start the worker via
// session.serviceWorkers.startWorkerForScope(). The subtlety: calling that
// right after loadExtension() resolves is a race — loadExtension() only
// guarantees the "extension-loaded" state, not that the service worker
// registration has actually been stored yet. Electron has a separate,
// later 'extension-ready' event specifically for "all necessary browser
// state is initialized to support the start of the extension's background
// page" — that's the actual signal to wait for. This function is called from
// that event handler (and from the manual "Restart worker" button, where the
// extension is already fully loaded so there's no race to worry about).
let swForceStartLog = []; // visible record of every attempt, so a silent failure here doesn't send us guessing blind again
// "Failed to start service worker" from startWorkerForScope() is just
// Electron's generic wrapper — it doesn't say *why*. The actual reason (a
// script error, a missing API the worker referenced at the top level, etc.)
// is reported separately as a console-message event from the worker itself.
// Listening for that is the only way to see the real error instead of the
// wrapper text.
let swConsoleLog = [];
async function forceStartServiceWorker(extId) {
  const record = result => {
    swForceStartLog = swForceStartLog.filter(r => r.extId !== extId).concat([{ extId, at: Date.now(), ...result }]);
  };

  const sw = session.defaultSession.serviceWorkers;
  if (!sw || !sw.startWorkerForScope) {
    record({ ok: false, note: "session.serviceWorkers.startWorkerForScope isn't available in this Electron version." });
    return;
  }
  const ext = extAPI().getAllExtensions().find(e => e.id === extId);
  if (!ext || !ext.manifest || ext.manifest.manifest_version !== 3 || !ext.manifest.background?.service_worker) {
    record({ ok: false, note: "Not an MV3 extension with a background service worker — nothing to start." });
    return;
  }
  try {
    const worker = await sw.startWorkerForScope(ext.url);
    record({ ok: true, versionId: worker && worker.versionId });
  } catch (e) {
    record({ ok: false, note: e.message });
    console.error(`Couldn't force-start the service worker for ${extId}:`, e.message);
  }
}

// --- Installing extensions from a .zip / .crx / URL / Chrome Web Store link ---

// Follows redirects itself (clients2.google.com hands back a 302 to the actual file host).
function downloadToBuffer(urlStr, redirectsLeft = 5) {
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(urlStr); } catch { return reject(new Error("That doesn't look like a valid URL.")); }
    if (!["http:", "https:"].includes(parsed.protocol)) {
      return reject(new Error("Only http/https URLs are supported."));
    }

    const lib = parsed.protocol === "https:" ? https : http;
    const req = lib.get(urlStr, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      }
    }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        res.resume();
        if (redirectsLeft <= 0) return reject(new Error("Too many redirects while downloading."));
        resolve(downloadToBuffer(new URL(res.headers.location, urlStr).toString(), redirectsLeft - 1));
        return;
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`Download failed (HTTP ${res.statusCode}).`));
      }
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => resolve(Buffer.concat(chunks)));
      res.on("error", reject);
    });
    req.on("error", e => reject(new Error(`Download failed: ${e.message}`)));
    req.setTimeout(20000, () => req.destroy(new Error("Download timed out.")));
  });
}

// A .crx file is a small binary header followed by a plain .zip payload.
// This strips the header (crx2 or crx3) so the rest can be unzipped normally.
function crxBufferToZipBuffer(buf) {
  if (buf.length < 16 || buf.toString("ascii", 0, 4) !== "Cr24") {
    throw new Error("Not a valid .crx file.");
  }
  const version = buf.readUInt32LE(4);
  let zipStart;
  if (version === 2) {
    const pubKeyLen = buf.readUInt32LE(8);
    const sigLen = buf.readUInt32LE(12);
    zipStart = 16 + pubKeyLen + sigLen;
  } else if (version === 3) {
    const headerLen = buf.readUInt32LE(8);
    zipStart = 12 + headerLen;
  } else {
    throw new Error(`Unsupported .crx version: ${version}`);
  }
  return buf.subarray(zipStart);
}

function runUnzip(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    fs.mkdirSync(destDir, { recursive: true });
    execFile("unzip", ["-o", "-q", zipPath, "-d", destDir], error => {
      if (error) {
        if (error.code === "ENOENT") {
          reject(new Error("This feature needs the 'unzip' command line tool (included by default on macOS)."));
        } else {
          reject(new Error("Couldn't unzip that file — it may not be a valid archive."));
        }
      } else {
        resolve();
      }
    });
  });
}

// Chrome extension IDs are always exactly 32 lowercase letters a-p.
function extractExtensionId(input) {
  const trimmed = input.trim();
  if (/^[a-p]{32}$/.test(trimmed)) return trimmed;
  const match = trimmed.match(/[a-p]{32}/);
  return match ? match[0] : null;
}

// The same endpoint the real Chrome browser uses to fetch/update extensions.
function buildWebStoreCrxUrl(extId) {
  const x = `id=${extId}&installsource=ondemand&uc`;
  return "https://clients2.google.com/service/update2/crx?response=redirect&os=mac&arch=x86-64" +
    `&os_arch=x86-64&nacl_arch=x86-64&prod=chromecrx&prodchannel=stable&prodversion=120.0.6099.129` +
    `&acceptformat=crx2,crx3&x=${encodeURIComponent(x)}`;
}

// Shared by "load from URL", "load from file", and Chrome Web Store installs.
async function installExtensionFromBuffer(buffer, label) {
  let zipBuffer;
  if (buffer.subarray(0, 4).toString("ascii") === "Cr24") {
    zipBuffer = crxBufferToZipBuffer(buffer);
  } else if (buffer[0] === 0x50 && buffer[1] === 0x4b) {
    zipBuffer = buffer; // already a zip (PK.. signature)
  } else {
    throw new Error(`That doesn't look like a .crx or .zip extension package${label ? ` (${label})` : ""}.`);
  }

  const tmpDir = fs.mkdtempSync(path.join(app.getPath("temp"), "minibrowser-ext-"));
  const zipPath = path.join(tmpDir, "package.zip");
  fs.writeFileSync(zipPath, zipBuffer);

  const destDir = path.join(dataDir(), "extensions", `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);

  try {
    await runUnzip(zipPath, destDir);
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  // Some downloads wrap the extension in a single top-level folder.
  let extPath = destDir;
  if (!fs.existsSync(path.join(extPath, "manifest.json"))) {
    const dirs = fs.readdirSync(destDir, { withFileTypes: true }).filter(e => e.isDirectory());
    if (dirs.length === 1 && fs.existsSync(path.join(destDir, dirs[0].name, "manifest.json"))) {
      extPath = path.join(destDir, dirs[0].name);
    }
  }
  if (!fs.existsSync(path.join(extPath, "manifest.json"))) {
    fs.rmSync(destDir, { recursive: true, force: true });
    throw new Error(`Couldn't find a manifest.json in ${label || "that package"}.`);
  }

  // The 'extension-ready' listener registered at startup handles starting
  // this extension's service worker once Electron actually reports it ready
  // — calling startWorkerForScope() right here would race the registration.
  const loadedExt = await extAPI().loadExtension(extPath, { allowFileAccess: true });

  extensionsConfig.push({ path: extPath, enabled: true });
  saveExtensionsConfig();
  sendState();
}

// Load every extension marked "enabled" the last time the app ran.
async function initExtensions() {
  try {
    extensionsConfig = JSON.parse(fs.readFileSync(extensionsFile(), "utf8"));
  } catch {
    extensionsConfig = [];
  }

  for (const cfg of extensionsConfig) {
    if (!cfg.enabled) continue;
    try {
      // extension-ready listener (registered before this runs) starts the
      // worker once it's actually safe to — see forceStartServiceWorker.
      await extAPI().loadExtension(cfg.path, { allowFileAccess: true });
    } catch (e) {
      console.error("Failed to load extension:", cfg.path, e.message);
    }
  }
}

const ICON_MIME = {
  ".png": "image/png", ".svg": "image/svg+xml", ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
  ".ico": "image/x-icon", ".bmp": "image/bmp"
};

// Prefer an icon >= 32px so an 18px button still looks sharp on a Retina
// display; fall back to the largest available.
function pickIconRelPath(manifest) {
  const action = manifest.action || manifest.browser_action || {};
  for (const set of [action.default_icon, manifest.icons]) {
    if (!set) continue;
    if (typeof set === "string") return set;
    const sizes = Object.keys(set)
      .map(k => ({ n: parseInt(k, 10), p: set[k] }))
      .filter(s => s.p && !Number.isNaN(s.n))
      .sort((a, b) => a.n - b.n);
    if (!sizes.length) continue;
    return (sizes.find(s => s.n >= 32) || sizes[sizes.length - 1]).p;
  }
  return null;
}

// Read the icon off disk and inline it as a data: URL. A chrome-extension://
// URL can't be used here: our toolbar is an ordinary page, so Chromium only
// lets it load extension files listed in the manifest's
// web_accessible_resources — and almost no extension lists its own icons.
function iconDataUrl(extPath, manifest) {
  const rel = pickIconRelPath(manifest);
  if (!rel) return null;
  const file = path.resolve(extPath, rel.replace(/^\.?\//, "")); // "/icons/x.png" and "./icons/x.png" both appear in the wild
  if (file !== path.resolve(extPath) && !file.startsWith(path.resolve(extPath) + path.sep)) return null;
  try {
    const buf = fs.readFileSync(file);
    const mime = ICON_MIME[path.extname(file).toLowerCase()] || "image/png";
    return `data:${mime};base64,${buf.toString("base64")}`;
  } catch {
    return null;
  }
}

// Build the list sent to the renderer: merges saved config + manifest info +
// live data (id / icon URL) for whichever extensions are currently loaded.
function buildExtensionState() {
  const loaded = extAPI().getAllExtensions();

  return extensionsConfig.map(cfg => {
    const manifest = readManifest(cfg.path) || {};
    const liveExt = loaded.find(e => e.path === cfg.path);
    const action = manifest.action || manifest.browser_action;

    const background = manifest.background
      ? (manifest.background.service_worker ? "service_worker" : "page")
      : null;

    return {
      path: cfg.path,
      enabled: !!cfg.enabled,
      id: liveExt ? liveExt.id : null,
      name: manifest.name || path.basename(cfg.path),
      version: manifest.version || "",
      manifestVersion: manifest.manifest_version || null,
      permissions: [...(manifest.permissions || []), ...(manifest.host_permissions || [])],
      hasPopup: !!(action && action.default_popup),
      iconUrl: iconDataUrl(cfg.path, manifest),
      background
    };
  });
}

function saveData() {
  fs.writeFileSync(bookmarksFile(), JSON.stringify(bookmarks, null, 2));
  fs.writeFileSync(historyFile(), JSON.stringify(history.slice(-500), null, 2));
}

function createWindow() {
  win = new BrowserWindow({
    width: 1300,
    height: 850,
    minWidth: 800,
    minHeight: 600,
    titleBarStyle: "hiddenInset",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile("index.html");
  win.on("resize", resizeView);
  win.on("enter-full-screen", resizeView);
  win.on("leave-full-screen", resizeView);

  createTab("https://www.google.com");
}

function createTab(url = "https://www.google.com") {
  const view = new BrowserView({
    webPreferences: {
      contextIsolation: true,
      sandbox: true
    }
  });

  // Keep a direct reference to this tab's own record. Using tabs[activeTab]
  // inside the listeners below would let a background tab's events overwrite
  // whichever tab happens to be active at that moment.
  const tabEntry = { view, url };
  tabs.push(tabEntry);
  win.addBrowserView(view);
  resizeView();
  switchTab(tabs.length - 1);

  view.webContents.setWindowOpenHandler(({ url }) => {
    createTab(url);
    return { action: "deny" };
  });

  view.webContents.on("did-navigate", (_, newUrl) => {
    tabEntry.url = newUrl;
    addHistory(newUrl);
    sendState();
  });

  view.webContents.on("did-navigate-in-page", (_, newUrl) => {
    tabEntry.url = newUrl;
    sendState();
  });

  view.webContents.on("page-title-updated", (_, title) => {
    tabEntry.title = title;
    sendState();
  });

  view.webContents.session.on("will-download", (_, item) => {
    const savePath = path.join(app.getPath("downloads"), item.getFilename());
    item.setSavePath(savePath);
  });

  view.webContents.loadURL(url);
}

function canGoBack(wc) {
  return wc.navigationHistory ? wc.navigationHistory.canGoBack() : wc.canGoBack();
}
function canGoForward(wc) {
  return wc.navigationHistory ? wc.navigationHistory.canGoForward() : wc.canGoForward();
}
function goBack(wc) {
  return wc.navigationHistory ? wc.navigationHistory.goBack() : wc.goBack();
}
function goForward(wc) {
  return wc.navigationHistory ? wc.navigationHistory.goForward() : wc.goForward();
}

function addHistory(url) {
  if (!url || url.startsWith("devtools://")) return;
  history.push({ url, time: Date.now() });
  history = history.slice(-500);
  saveData();
}

function resizeView() {
  if (!win || !tabs[activeTab]) return;
  const bounds = win.getContentBounds();
  const width = Math.max(0, bounds.width - (panelOpen ? panelWidth : 0));
  tabs[activeTab].view.setBounds({
    x: 0, y: toolbarHeight, width, height: Math.max(0, bounds.height - toolbarHeight)
  });
}

function switchTab(index) {
  if (!tabs[index]) return;
  tabs.forEach(t => win.removeBrowserView(t.view));
  activeTab = index;
  win.addBrowserView(tabs[index].view);
  resizeView();
  sendState();
}

function closeTab(index) {
  if (!tabs[index]) return;
  win.removeBrowserView(tabs[index].view);
  tabs[index].view.webContents.destroy();
  tabs.splice(index, 1);

  if (!tabs.length) {
    createTab();
    return;
  }
  activeTab = Math.min(activeTab, tabs.length - 1);
  switchTab(activeTab);
}

function navigate(input) {
  if (!tabs[activeTab]) return;
  let value = input.trim();
  if (!value) return;

  let url;
  try {
    url = new URL(value.includes("://") ? value : `https://${value}`);
  } catch {
    url = new URL(`https://www.google.com/search?q=${encodeURIComponent(value)}`);
  }

  tabs[activeTab].view.webContents.loadURL(url.toString());
}

function sendState() {
  if (!win || win.isDestroyed()) return;

  const t = tabs[activeTab];
  win.webContents.send("browser-state", {
    tabs: tabs.map((tab, i) => ({
      index: i,
      title: tab.title || "New Tab",
      url: tab.url || ""
    })),
    active: activeTab,
    address: t ? t.view.webContents.getURL() : "",
    canGoBack: t ? canGoBack(t.view.webContents) : false,
    canGoForward: t ? canGoForward(t.view.webContents) : false,
    bookmarks,
    history,
    extensions: buildExtensionState(),
    proxy: { mode: proxyConfig.mode, authFailed: lastProxyAuthFailed }
  });
}

ipcMain.on("navigate", (_, value) => navigate(value));
ipcMain.on("new-tab", (_, url) => createTab(url || "https://www.google.com"));
ipcMain.on("switch-tab", (_, i) => switchTab(Number(i)));
ipcMain.on("close-tab", (_, i) => closeTab(Number(i)));
ipcMain.on("back", () => { if (tabs[activeTab]) goBack(tabs[activeTab].view.webContents); });
ipcMain.on("forward", () => { if (tabs[activeTab]) goForward(tabs[activeTab].view.webContents); });
ipcMain.on("reload", () => tabs[activeTab]?.view.webContents.reload());
ipcMain.on("bookmark", () => {
  const url = tabs[activeTab]?.view.webContents.getURL();
  if (!url) return;
  if (!bookmarks.some(b => b.url === url)) {
    bookmarks.push({ title: tabs[activeTab].title || url, url });
  }
  saveData();
  sendState();
});
ipcMain.on("open-external", (_, url) => shell.openExternal(url));
ipcMain.on("devtools", () => tabs[activeTab]?.view.webContents.openDevTools({ mode: "detach" }));

ipcMain.on("ui-metrics", (_, metrics) => {
  if (metrics && typeof metrics.toolbarHeight === "number" && metrics.toolbarHeight > 0) {
    toolbarHeight = metrics.toolbarHeight;
  }
  if (metrics && typeof metrics.panelWidth === "number") {
    panelWidth = metrics.panelWidth;
  }
  resizeView();
});

ipcMain.on("panel-open", (_, open) => {
  panelOpen = !!open;
  resizeView();
});

// --- Extension management ---

ipcMain.handle("ext-load-unpacked", async () => {
  const result = await dialog.showOpenDialog(win, {
    title: "Select an unpacked extension folder",
    properties: ["openDirectory"]
  });
  if (result.canceled || !result.filePaths[0]) return { ok: false };

  const extPath = result.filePaths[0];
  if (!readManifest(extPath)) {
    return { ok: false, error: "That folder doesn't contain a manifest.json." };
  }

  try {
    // extension-ready listener handles starting the worker once it's safe to.
    await extAPI().loadExtension(extPath, { allowFileAccess: true });
  } catch (e) {
    return { ok: false, error: e.message };
  }

  const existing = extensionsConfig.find(c => c.path === extPath);
  if (existing) existing.enabled = true;
  else extensionsConfig.push({ path: extPath, enabled: true });

  saveExtensionsConfig();
  sendState();
  return { ok: true };
});

ipcMain.handle("ext-add-from-url", async (_, input) => {
  try {
    const trimmed = (input || "").trim();
    if (!trimmed) return { ok: false, error: "Enter a URL, Chrome Web Store link, or extension ID first." };

    let downloadUrl = trimmed;
    const looksLikeDirectUrl = /^https?:\/\//i.test(trimmed) && /\.(zip|crx)(\?|#|$)/i.test(trimmed);
    if (!looksLikeDirectUrl) {
      // Chrome Web Store link or bare 32-character extension ID.
      const extId = extractExtensionId(trimmed);
      if (!extId) {
        return { ok: false, error: "Couldn't find an extension ID in that. Paste a Chrome Web Store link, a 32-letter extension ID, or a direct .zip/.crx URL." };
      }
      downloadUrl = buildWebStoreCrxUrl(extId);
    }

    const buffer = await downloadToBuffer(downloadUrl);
    await installExtensionFromBuffer(buffer, trimmed);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("ext-add-from-file", async () => {
  const result = await dialog.showOpenDialog(win, {
    title: "Select a .zip or .crx extension package",
    properties: ["openFile"],
    filters: [{ name: "Extension package", extensions: ["zip", "crx"] }]
  });
  if (result.canceled || !result.filePaths[0]) return { ok: false };

  try {
    const buffer = fs.readFileSync(result.filePaths[0]);
    await installExtensionFromBuffer(buffer, path.basename(result.filePaths[0]));
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("ext-toggle", async (_, extPath, enabled) => {
  const cfg = extensionsConfig.find(c => c.path === extPath);
  if (!cfg) return { ok: false, error: "Unknown extension." };

  if (enabled) {
    try {
      // extension-ready listener handles starting the worker once it's safe to.
      await extAPI().loadExtension(extPath, { allowFileAccess: true });
    } catch (e) {
      return { ok: false, error: e.message };
    }
  } else {
    const loaded = extAPI().getAllExtensions().find(e => e.path === extPath);
    if (loaded) extAPI().removeExtension(loaded.id);
    const popup = popupWindows.get(loaded?.id);
    if (popup) popup.close();
  }

  cfg.enabled = enabled;
  saveExtensionsConfig();
  sendState();
  return { ok: true };
});

ipcMain.handle("ext-remove", async (_, extPath) => {
  const loaded = extAPI().getAllExtensions().find(e => e.path === extPath);
  if (loaded) {
    extAPI().removeExtension(loaded.id);
    const popup = popupWindows.get(loaded.id);
    if (popup) popup.close();
  }

  extensionsConfig = extensionsConfig.filter(c => c.path !== extPath);
  saveExtensionsConfig();

  // Clean up the extracted copy for extensions we downloaded/installed ourselves
  // (anything under our own managed "extensions" folder). Leave user-picked
  // unpacked folders on disk untouched — we don't own those.
  const managedRoot = path.join(dataDir(), "extensions");
  if (extPath.startsWith(managedRoot + path.sep)) {
    try { fs.rmSync(extPath, { recursive: true, force: true }); } catch {}
  }

  sendState();
  return { ok: true };
});

// Overlays a small explanatory banner on top of whatever (if anything)
// rendered in the popup window, so a blank popup doesn't look like nothing
// happened.
function showPopupError(popupWin, message, detail) {
  if (popupWin.isDestroyed()) return;
  // Pass strings through JSON.stringify rather than hand-building the
  // injected JS, so error text/URLs with quotes, backticks, etc. can't break
  // (or escape) the generated script.
  const payload = JSON.stringify({ message: message || "", detail: detail || "" });
  const js = `
    (function(data) {
      if (document.getElementById("__mb_err_banner")) return;
      var b = document.createElement("div");
      b.id = "__mb_err_banner";
      b.style.cssText = "position:fixed;inset:0;z-index:2147483647;background:#20212699;" +
        "backdrop-filter:blur(2px);color:#fff;font:13px -apple-system,sans-serif;" +
        "padding:16px;box-sizing:border-box;overflow:auto;";
      var title = document.createElement("b");
      title.textContent = "⚠️ " + data.message;
      b.appendChild(title);
      if (data.detail) {
        var d = document.createElement("div");
        d.style.cssText = "margin-top:8px;opacity:.75;word-break:break-all;";
        d.textContent = data.detail;
        b.appendChild(d);
      }
      var note = document.createElement("div");
      note.style.cssText = "margin-top:12px;opacity:.75;";
      note.textContent = "Electron only supports a subset of Chrome's extension APIs, so some Chrome Web Store extensions won't run correctly here.";
      b.appendChild(note);
      document.documentElement.appendChild(b);
    })(${payload});
  `;
  popupWin.webContents.executeJavaScript(js).catch(() => {});
}

// Chrome-Web-Store popups commonly throw immediately (calling chrome.* APIs
// Electron doesn't implement) before painting anything, leaving a genuinely
// blank white window with no error dialog anywhere. Catch that case and
// explain it, instead of leaving the person staring at nothing.

ipcMain.handle("ext-open-popup", async (_, extId, anchor) => {
  const ext = extAPI().getAllExtensions().find(e => e.id === extId);
  if (!ext) return { ok: false, error: "That extension isn't loaded." };

  const action = ext.manifest.action || ext.manifest.browser_action;
  const popupPath = action && action.default_popup;
  if (!popupPath) return { ok: false, error: "This extension doesn't have a popup." };

  const existing = popupWindows.get(extId);
  if (existing && !existing.isDestroyed()) {
    existing.focus();
    return { ok: true };
  }

  // Placeholder geometry — we don't know the popup's real size until its
  // content loads, so this just needs to exist somewhere sane on screen.
  // clampToAnchor() below does the actual positioning once we know the size.
  const popupWin = new BrowserWindow({
    x: Math.round((anchor && anchor.x) || 100),
    y: Math.round((anchor && anchor.y) || 100),
    width: 380,
    height: 1, // near-zero: avoids a flash of the wrong size before we measure
    frame: false,          // no title bar / traffic lights — reads as a dropdown, not a window
    resizable: false,
    movable: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: true,       // macOS gives frameless+shadow the native popover look
    roundedCorners: true,
    show: false,
    backgroundColor: "#00000000",
    parent: win,
    // No `sandbox: true` here — Electron injects its chrome.* extension
    // bindings through an internal preload, and sandboxing the popup can stop
    // those bindings from reaching the page, which makes chrome.runtime
    // undefined and kills the popup script on its first line.
    webPreferences: { contextIsolation: true }
  });
  popupWin.setMenu(null);

  popupWin.webContents.on("did-fail-load", (_e, errorCode, errorDescription, validatedURL) => {
    if (errorCode === -3) return; // ERR_ABORTED, usually just a redirect/navigation cancel
    showPopupError(popupWin, `This popup failed to load (${errorDescription || errorCode}).`, validatedURL);
  });
  popupWin.webContents.on("render-process-gone", (_e, details) => {
    showPopupError(popupWin, `The popup's page crashed (${details.reason}).`);
  });

  // A contextIsolation preload's `window` lives in a separate isolated JS
  // world from the popup's own page script, so a preload-side
  // window.addEventListener('error') never actually sees the page's uncaught
  // exceptions — they fire on the main world's window, a different object.
  // The console-message event (main-process side) does reliably catch them,
  // since Chromium always logs uncaught errors to the console regardless of
  // which world threw. We only act on it if the popup also still looks empty
  // a moment later, so extensions that catch their own errors and still
  // render fine aren't flagged.
  let sawRuntimeError = null;
  // Electron 35 changed this event: listeners now get a single object and
  // `level` is a string ("error"), not the old numeric 3. Accept both shapes
  // so this keeps working either way.
  popupWin.webContents.on("console-message", (eventOrArg, legacyLevel, legacyMessage) => {
    const isEventObject = eventOrArg && typeof eventOrArg === "object" && "level" in eventOrArg;
    const level = isEventObject ? eventOrArg.level : legacyLevel;
    const message = isEventObject ? eventOrArg.message : legacyMessage;
    if ((level === "error" || level === 3) && !sawRuntimeError) sawRuntimeError = message;
  });
  popupWin.webContents.once("did-finish-load", () => {
    setTimeout(async () => {
      if (!sawRuntimeError || popupWin.isDestroyed()) return;
      try {
        // Checking for text or an <img> misses popups that draw via CSS
        // backgrounds, and misses ones whose markup exists but never got laid
        // out. Ask whether anything actually occupies space instead.
        const empty = await popupWin.webContents.executeJavaScript(`
          (function () {
            var b = document.body;
            if (!b) return true;
            if (b.innerText.trim().length) return false;
            return !Array.prototype.some.call(b.querySelectorAll("*"), function (el) {
              var r = el.getBoundingClientRect();
              return r.width > 8 && r.height > 8;
            });
          })()
        `);
        if (empty) {
          showPopupError(popupWin, "This extension's popup script hit an error before it could render.", sawRuntimeError);
        }
      } catch {}
    }, 300);
  });

  popupWin.loadURL(`chrome-extension://${extId}/${popupPath}`);

  // Chrome sizes an action popup to its own content (up to a max), then
  // anchors it under the icon, right-aligned since icons sit near the
  // toolbar's right edge. We approximate that: measure the loaded page,
  // clamp to sane bounds, then place the window from the anchor rect the
  // renderer sent us.
  const MIN_W = 180, MAX_W = 800, MIN_H = 100, MAX_H = 600;

  function placeNearAnchor(width, height) {
    if (popupWin.isDestroyed()) return;
    const display = screen.getDisplayMatching(
      anchor
        ? { x: Math.round(anchor.x), y: Math.round(anchor.y), width: 1, height: 1 }
        : win.getBounds()
    );
    const area = display.workArea;

    // Right-align under the icon by default (icons live near the toolbar's
    // right edge, so left-aligning would usually run the popup off-screen).
    let x = anchor ? Math.round(anchor.x + anchor.width - width) : area.x + 40;
    let y = anchor ? Math.round(anchor.y + anchor.height + 6) : area.y + 40;

    // Keep the whole popup on the display that owns the anchor point.
    x = Math.min(Math.max(x, area.x), area.x + area.width - width);
    y = Math.min(Math.max(y, area.y), area.y + area.height - height);

    popupWin.setBounds({ x, y, width, height });
  }

  // Start at a reasonable default so there's something visible immediately
  // if measuring the content takes a moment or fails outright.
  placeNearAnchor(380, 550);

  popupWin.webContents.once("did-finish-load", () => {
    setTimeout(async () => {
      if (popupWin.isDestroyed()) return;
      try {
        const size = await popupWin.webContents.executeJavaScript(`
          (function () {
            var b = document.body, d = document.documentElement;
            return {
              width: Math.max(b ? b.scrollWidth : 0, d.scrollWidth),
              height: Math.max(b ? b.scrollHeight : 0, d.scrollHeight)
            };
          })()
        `);
        const width = Math.min(MAX_W, Math.max(MIN_W, Math.ceil(size.width) || 380));
        const height = Math.min(MAX_H, Math.max(MIN_H, Math.ceil(size.height) || 550));
        placeNearAnchor(width, height);
      } catch {
        // Content never rendered anything measurable — showPopupError below
        // will already be putting an explanation on screen at the default size.
      }
      if (!popupWin.isDestroyed()) popupWin.show();
    }, 60); // let layout settle after did-finish-load before measuring
  });

  // Close-on-blur mimics how Chrome dismisses an action popup when you click
  // elsewhere. But wiring this up immediately races the window's initial
  // focus assignment — the popup can blur (and close) before it has even
  // finished painting, which looks exactly like "clicking the icon does
  // nothing." Give it a moment to settle first.
  let armed = false;
  setTimeout(() => { armed = true; }, 400);
  popupWin.on("blur", () => {
    if (!armed) return;
    if (!popupWin.webContents.isDevToolsOpened()) popupWin.close();
  });
  popupWin.on("closed", () => popupWindows.delete(extId));

  popupWindows.set(extId, popupWin);
  return { ok: true };
});

ipcMain.handle("ext-inspect-popup", async (_, extId) => {
  const popupWin = popupWindows.get(extId);
  if (popupWin && !popupWin.isDestroyed()) {
    popupWin.webContents.openDevTools({ mode: "detach" });
    return { ok: true };
  }
  return { ok: false, error: "Open the popup first, then inspect it." };
});

ipcMain.handle("ext-background-info", async (_, extId) => {
  const ext = extAPI().getAllExtensions().find(e => e.id === extId);
  if (!ext) return { ok: true, running: null, note: "Extension isn't loaded." };

  const sw = session.defaultSession.serviceWorkers;
  if (!sw || !sw.getAllRunning) {
    return { ok: true, running: null, note: "Background worker status isn't available in this Electron version." };
  }

  try {
    const all = await sw.getAllRunning();
    const match = Object.values(all).find(w => w.scope && w.scope.startsWith(`chrome-extension://${extId}`));
    return { ok: true, running: !!match, scriptUrl: match ? match.scriptUrl : null };
  } catch (e) {
    return { ok: true, running: null, note: "Couldn't read background worker status." };
  }
});

ipcMain.handle("ext-restart-worker", async (_, extId) => {
  const ext = extAPI().getAllExtensions().find(e => e.id === extId);
  if (!ext) return { ok: false, error: "That extension isn't loaded." };
  try {
    await forceStartServiceWorker(extId);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// --- chrome.proxy shim plumbing ---
// Chrome hands extensions a structured ProxyConfig; Electron's setProxy wants
// Chromium's flat rule-string form. This is the translation between them.
let extensionProxy = null;      // last config an extension asked for
let shimStatus = [];            // chrome.proxy shim diagnostics
let msgLog = [];                 // chrome.runtime message-passing diagnostics
let msgInstrumentationStatus = [];

function chromeServerToString(server, defaultScheme) {
  if (!server || !server.host) return null;
  const scheme = server.scheme || defaultScheme || "http";
  // Chrome spells it "socks5"/"socks4"; Chromium's rule syntax wants the same,
  // except plain "socks" means socks4, so be explicit.
  const port = server.port ? `:${server.port}` : "";
  return `${scheme}://${server.host}${port}`;
}

function chromeConfigToElectron(config) {
  const mode = (config && config.mode) || "direct";

  if (mode === "direct") return { options: { mode: "direct" } };
  if (mode === "auto_detect") return { options: { mode: "auto_detect" } };
  if (mode === "system") return { options: { mode: "system" } };

  if (mode === "pac_script") {
    const pac = config.pacScript || {};
    if (pac.url) return { options: { mode: "pac_script", pacScript: pac.url } };
    if (pac.data) {
      // Electron only accepts a URL, but extensions very often ship the PAC
      // inline. Spill it to a temp file and point Chromium at that instead.
      const file = path.join(app.getPath("temp"), `minibrowser-pac-${Date.now()}.pac`);
      fs.writeFileSync(file, pac.data, "utf8");
      return { options: { mode: "pac_script", pacScript: `file://${file}` } };
    }
    return { error: "The extension supplied a PAC script with neither a url nor data." };
  }

  if (mode === "fixed_servers") {
    const rules = config.rules || {};
    let proxyRules;
    if (rules.singleProxy) {
      proxyRules = chromeServerToString(rules.singleProxy);
    } else {
      const parts = [];
      if (rules.proxyForHttp) parts.push(`http=${chromeServerToString(rules.proxyForHttp)}`);
      if (rules.proxyForHttps) parts.push(`https=${chromeServerToString(rules.proxyForHttps)}`);
      if (rules.proxyForFtp) parts.push(`ftp=${chromeServerToString(rules.proxyForFtp)}`);
      if (rules.fallbackProxy) parts.push(chromeServerToString(rules.fallbackProxy));
      proxyRules = parts.join(";");
    }
    if (!proxyRules) return { error: "The extension asked for fixed_servers but named no server." };

    const bypass = Array.isArray(rules.bypassList) && rules.bypassList.length
      ? rules.bypassList.join(",")
      : "";
    return { options: { proxyRules, proxyBypassRules: bypass } };
  }

  return { error: `Unsupported proxy mode from extension: ${mode}` };
}

ipcMain.handle("chrome-proxy-set", async (_, config) => {
  // A manual setting in the Proxy panel is an explicit user decision, so it
  // outranks whatever an extension wants — otherwise the extension silently
  // overwrites a choice the person made and the UI starts lying.
  if (proxyConfig.mode !== "direct") {
    return { ok: false, error: "A manual proxy is set in Circut; clear it to let the extension take over." };
  }

  const { options, error } = chromeConfigToElectron(config);
  if (error) {
    extensionProxy = { config, error, at: Date.now() };
    sendState();
    return { ok: false, error };
  }

  try {
    await session.defaultSession.setProxy(options);
    try { await session.defaultSession.closeAllConnections(); } catch {}
  } catch (e) {
    extensionProxy = { config, error: e.message, at: Date.now() };
    sendState();
    return { ok: false, error: e.message };
  }

  lastProxyAuthFailed = false;
  extensionProxy = { config, applied: options, at: Date.now() };
  sendState();
  return { ok: true };
});

ipcMain.handle("chrome-proxy-get", async () => ({
  userSet: proxyConfig.mode !== "direct"
}));

ipcMain.on("chrome-proxy-shim-status", (_, info) => {
  shimStatus = shimStatus.filter(s => s.context !== info.context).concat([{ ...info, at: Date.now() }]);
  sendState();
});

// A 5s no-reply verdict for one call doesn't mean the whole channel is dead
// (a slow but real response would still land after this fires), so this is
// diagnostic evidence, not a guarantee — but it's the difference between
// "something is stuck" and "everything crashed silently."
const MSG_LOG_CAP = 200;
ipcMain.on("ext-msg-log", (_, entry) => {
  msgLog.push({ ...entry, at: Date.now() });
  if (msgLog.length > MSG_LOG_CAP) msgLog.splice(0, msgLog.length - MSG_LOG_CAP);
});

ipcMain.on("ext-msg-instrumentation-status", (_, info) => {
  msgInstrumentationStatus = msgInstrumentationStatus
    .filter(s => s.context !== info.context)
    .concat([{ ...info, at: Date.now() }]);
});

ipcMain.handle("ext-msg-log-get", async () => ({
  log: msgLog.slice().reverse(), // newest first
  instrumentation: msgInstrumentationStatus,
  swForceStart: swForceStartLog,
  swConsole: swConsoleLog.slice().reverse()
}));

ipcMain.handle("ext-msg-log-clear", async () => {
  msgLog = [];
  return { ok: true };
});

ipcMain.handle("proxy-shim-info", async () => ({
  shim: shimStatus,
  extensionProxy: extensionProxy
    ? {
        mode: extensionProxy.config && extensionProxy.config.mode,
        applied: extensionProxy.applied || null,
        error: extensionProxy.error || null,
        at: extensionProxy.at
      }
    : null
}));

ipcMain.handle("proxy-get", async () => {
  // Never ship the password back to the renderer; just say whether one is set.
  const { password, ...rest } = proxyConfig;
  return { ...rest, hasPassword: !!password, authFailed: lastProxyAuthFailed };
});

ipcMain.handle("proxy-set", async (_, cfg) => {
  const mode = ["direct", "system", "fixed", "pac"].includes(cfg.mode) ? cfg.mode : "direct";
  if (mode === "fixed" && !String(cfg.rules || "").trim()) {
    return { ok: false, error: "Enter a proxy server, e.g. socks5://127.0.0.1:1080" };
  }
  if (mode === "pac" && !String(cfg.pac || "").trim()) {
    return { ok: false, error: "Enter the URL of a PAC script." };
  }

  proxyConfig = {
    mode,
    rules: String(cfg.rules || "").trim(),
    pac: String(cfg.pac || "").trim(),
    bypass: String(cfg.bypass ?? "<local>"),
    username: String(cfg.username || ""),
    // An omitted password field means "keep the saved one" rather than "clear it",
    // so the renderer never has to round-trip the secret just to change the host.
    password: cfg.password === undefined ? proxyConfig.password : String(cfg.password || "")
  };

  try {
    await applyProxy();
  } catch (e) {
    return { ok: false, error: `Couldn't apply that proxy: ${e.message}` };
  }
  saveProxyConfig();
  sendState();
  return { ok: true };
});

// Two different questions, both worth answering: which proxy would Chromium
// pick for a URL (local, instant, proves the rules parsed), and what does the
// outside world actually see (real request, proves the tunnel works).
ipcMain.handle("proxy-test", async () => {
  const ses = session.defaultSession;
  const testUrl = "https://api.ipify.org?format=json";

  let resolved = "unknown";
  try { resolved = await ses.resolveProxy(testUrl); } catch {}

  const ip = await new Promise(resolve => {
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    try {
      const request = net.request({ url: testUrl, session: ses, useSessionCookies: false });
      const timer = setTimeout(() => { try { request.abort(); } catch {} finish({ error: "Timed out after 15s." }); }, 15000);
      request.on("response", response => {
        const chunks = [];
        response.on("data", c => chunks.push(c));
        response.on("end", () => {
          clearTimeout(timer);
          try { finish({ ip: JSON.parse(Buffer.concat(chunks).toString("utf8")).ip }); }
          catch { finish({ error: "Unexpected response from the IP check service." }); }
        });
        response.on("error", e => { clearTimeout(timer); finish({ error: e.message }); });
      });
      request.on("error", e => { clearTimeout(timer); finish({ error: e.message }); });
      request.end();
    } catch (e) {
      finish({ error: e.message });
    }
  });

  return { ok: true, resolved, ...ip, authFailed: lastProxyAuthFailed };
});

app.whenReady().then(async () => {
  loadData();

  // Register before loadExtension runs: the service worker preload realm must
  // already exist when the background worker first evaluates, or the extension
  // reaches for chrome.proxy before it's there.
  try {
    session.defaultSession.registerPreloadScript({
      type: "service-worker",
      id: "minibrowser-proxy-shim-sw",
      filePath: path.join(__dirname, "ext-sw-preload.js")
    });
    session.defaultSession.registerPreloadScript({
      type: "frame",
      id: "minibrowser-proxy-shim-frame",
      filePath: path.join(__dirname, "ext-frame-preload.js")
    });
  } catch (e) {
    console.error("Couldn't register the chrome.proxy shim (needs Electron 35+):", e.message);
  }

  // Must be registered before initExtensions() runs: 'extension-ready' fires
  // once per load, and if we're not listening yet when it fires for the
  // extensions restored on startup — which is every extension, on every
  // launch after the first — we silently miss the one signal that tells us
  // it's actually safe to force-start the background worker.
  extAPI().on("extension-loaded", () => sendState());
  extAPI().on("extension-unloaded", () => sendState());
  extAPI().on("extension-ready", (_event, extension) => {
    forceStartServiceWorker(extension.id);
    sendState();
  });

  // Capture the service worker's own console output — this is where the real
  // reason a worker fails to start actually shows up (a script error, a
  // reference to an API Electron doesn't implement, etc.), as opposed to the
  // generic "Failed to start service worker" wrapper text startWorkerForScope
  // throws. We extract the extension id from whatever chrome-extension://
  // URL the event carries, since messageDetails doesn't hand us extId directly.
  if (session.defaultSession.serviceWorkers && session.defaultSession.serviceWorkers.on) {
    session.defaultSession.serviceWorkers.on("console-message", (_event, details) => {
      const idMatch = JSON.stringify(details).match(/chrome-extension:\/\/([a-z]{32})/);
      swConsoleLog.push({
        extId: idMatch ? idMatch[1] : null,
        level: details.level,
        message: details.message,
        source: details.source,
        sourceUrl: details.sourceUrl || details.source,
        lineNumber: details.lineNumber,
        at: Date.now()
      });
      if (swConsoleLog.length > 200) swConsoleLog.splice(0, swConsoleLog.length - 200);
    });
  }

  try { await applyProxy(); } catch (e) { console.error("Couldn't apply saved proxy:", e.message); }
  await initExtensions(); // restore extensions enabled on a previous run
  createWindow();

  // Authenticated proxies challenge with a 407. Chromium can't answer that on
  // its own, so without this handler every request silently dies and the
  // browser just looks broken. Answering once per challenge and refusing on
  // the retry avoids an infinite auth loop when the credentials are wrong.
  const triedAuth = new Set();
  app.on("login", (event, webContents, details, authInfo, callback) => {
    if (!authInfo.isProxy) return; // let normal site logins behave normally
    event.preventDefault();

    const key = `${authInfo.host}:${authInfo.port}`;
    if (triedAuth.has(key) || !proxyConfig.username) {
      lastProxyAuthFailed = true;
      triedAuth.delete(key);
      sendState();
      return callback();
    }
    triedAuth.add(key);
    setTimeout(() => triedAuth.delete(key), 30000);
    callback(proxyConfig.username, proxyConfig.password);
  });

  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    const isExtensionPage = webContents.getURL().startsWith("chrome-extension://");
    // Extension pages (popups, background) get a slightly wider default allow-list
    // since these permissions were already declared and reviewed in the manifest;
    // everything else on the open web stays conservative.
    const allowed = isExtensionPage
      ? ["clipboard-read", "clipboard-sanitized-write", "notifications"].includes(permission)
      : ["clipboard-read", "clipboard-sanitized-write"].includes(permission);
    callback(allowed);
  });

  session.defaultSession.setPermissionCheckHandler((webContents, permission, requestingOrigin) => {
    if (requestingOrigin && requestingOrigin.startsWith("chrome-extension://")) return true;
    return ["clipboard-read", "clipboard-sanitized-write"].includes(permission);
  });

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
