const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("browserAPI", {
  navigate: value => ipcRenderer.send("navigate", value),
  newTab: url => ipcRenderer.send("new-tab", url),
  switchTab: index => ipcRenderer.send("switch-tab", index),
  closeTab: index => ipcRenderer.send("close-tab", index),
  back: () => ipcRenderer.send("back"),
  forward: () => ipcRenderer.send("forward"),
  reload: () => ipcRenderer.send("reload"),
  bookmark: () => ipcRenderer.send("bookmark"),
  devtools: () => ipcRenderer.send("devtools"),
  onState: callback => ipcRenderer.on("browser-state", (_, state) => callback(state)),

  // Extensions
  loadUnpackedExtension: () => ipcRenderer.invoke("ext-load-unpacked"),
  addExtensionFromUrl: input => ipcRenderer.invoke("ext-add-from-url", input),
  addExtensionFromFile: () => ipcRenderer.invoke("ext-add-from-file"),
  toggleExtension: (extPath, enabled) => ipcRenderer.invoke("ext-toggle", extPath, enabled),
  removeExtension: extPath => ipcRenderer.invoke("ext-remove", extPath),
  openExtensionPopup: (extId, anchor) => ipcRenderer.invoke("ext-open-popup", extId, anchor),
  inspectExtensionPopup: extId => ipcRenderer.invoke("ext-inspect-popup", extId),
  getExtensionBackgroundInfo: extId => ipcRenderer.invoke("ext-background-info", extId),
  restartExtensionWorker: extId => ipcRenderer.invoke("ext-restart-worker", extId),

  // Proxy
  getProxy: () => ipcRenderer.invoke("proxy-get"),
  setProxy: cfg => ipcRenderer.invoke("proxy-set", cfg),
  testProxy: () => ipcRenderer.invoke("proxy-test"),
  getProxyShimInfo: () => ipcRenderer.invoke("proxy-shim-info"),
  getExtMessageLog: () => ipcRenderer.invoke("ext-msg-log-get"),
  clearExtMessageLog: () => ipcRenderer.invoke("ext-msg-log-clear"),

  // UI layout — lets main.js keep the actual web page out of the toolbar/panel area,
  // since that native layer always renders above this HTML UI regardless of CSS.
  reportUIMetrics: metrics => ipcRenderer.send("ui-metrics", metrics),
  reportPanelOpen: open => ipcRenderer.send("panel-open", open)
});
