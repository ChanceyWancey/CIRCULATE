// Same chrome.proxy shim, but for extension *pages* (popups, options pages).
// Registered session-wide, so the protocol guard matters: ordinary web pages
// must not be touched, and they have no `chrome` bindings to patch anyway.
//
// IMPORTANT: sandboxed preload scripts can only require a small whitelist of
// Electron/Node built-ins — a plain require("./local-file") throws "module not
// found" and aborts the whole preload before it runs (this is what broke Browsec
// the first time: the shim never installed and its popup died on its first
// chrome.proxy call). So this function is inlined here rather than imported
// from a shared file. Keep ext-sw-preload.js's copy in sync if you change this.
const { contextBridge, ipcRenderer } = require("electron");

if (location.protocol === "chrome-extension:") {
  const applyProxy = config => ipcRenderer.invoke("chrome-proxy-set", config);
  const readProxy = () => ipcRenderer.invoke("chrome-proxy-get");

  const mainWorldInstaller = function (applyProxy, readProxy) {
  if (typeof chrome === "undefined" || !chrome) return "no-chrome";
  if (chrome.proxy && chrome.proxy.__miniBrowserShim) return "already-installed";

  // Mirrors what the extension last asked for, so settings.get() reflects its
  // own writes even though the real state lives in the main process.
  var current = { mode: "direct" };

  // Extensions commonly register these at startup and would crash on an
  // undefined event object, so they exist even though we never fire them.
  function makeEvent() {
    var listeners = [];
    return {
      addListener: function (fn) { if (typeof fn === "function") listeners.push(fn); },
      removeListener: function (fn) {
        var i = listeners.indexOf(fn);
        if (i !== -1) listeners.splice(i, 1);
      },
      hasListener: function (fn) { return listeners.indexOf(fn) !== -1; },
      hasListeners: function () { return listeners.length > 0; }
    };
  }

  // chrome.proxy is callback-style but also returns a promise under MV3.
  // Support both, and surface failures through chrome.runtime.lastError the way
  // the real API does rather than rejecting into the void.
  function dual(work, callback) {
    var promise = Promise.resolve().then(work);
    if (typeof callback !== "function") return promise;
    promise.then(
      function (value) { callback(value); },
      function (err) {
        try { chrome.runtime.lastError = { message: String((err && err.message) || err) }; } catch (e) {}
        try { callback(); } finally {
          try { delete chrome.runtime.lastError; } catch (e) {}
        }
      }
    );
    return undefined;
  }

  var shim = {
    __miniBrowserShim: true,
    settings: {
      get: function (details, callback) {
        return dual(function () {
          return Promise.resolve(readProxy()).then(function (live) {
            return {
              value: current,
              levelOfControl: live && live.userSet
                ? "controlled_by_other_extensions"
                : "controlled_by_this_extension"
            };
          });
        }, callback);
      },
      set: function (details, callback) {
        return dual(function () {
          current = (details && details.value) || { mode: "direct" };
          return Promise.resolve(applyProxy(current)).then(function (res) {
            if (!res || !res.ok) throw new Error((res && res.error) || "setProxy failed");
          });
        }, callback);
      },
      clear: function (details, callback) {
        return dual(function () {
          current = { mode: "direct" };
          return Promise.resolve(applyProxy(current));
        }, callback);
      },
      onChange: makeEvent()
    },
    onProxyError: makeEvent()
  };

  // `chrome` is sometimes non-writable depending on how bindings were
  // installed, so fall back to defineProperty before giving up.
  try {
    chrome.proxy = shim;
  } catch (e) {
    try {
      Object.defineProperty(chrome, "proxy", { value: shim, configurable: true, writable: true });
    } catch (e2) {
      return "failed-to-attach";
    }
  }
  return chrome.proxy && chrome.proxy.__miniBrowserShim ? "installed" : "failed-to-attach";
};

  try {
    const result = contextBridge.executeInMainWorld({
      func: mainWorldInstaller,
      args: [applyProxy, readProxy]
    });
    ipcRenderer.send("chrome-proxy-shim-status", { context: "extension-page", result });
  } catch (err) {
    ipcRenderer.send("chrome-proxy-shim-status", {
      context: "extension-page",
      result: "error",
      error: String((err && err.message) || err)
    });
  }

  // --- Message-passing diagnostics ---
  // Popups commonly render nothing until a message to the background service
  // worker round-trips. A dropped/stalled channel looks identical from the UI
  // side to a crashed script — blank, nothing in the console — so this wraps
  // sendMessage/onMessage to make that distinction visible in the Extensions
  // panel instead of guessing blind.
  const logMessage = entry => ipcRenderer.send("ext-msg-log", entry);

  function mainWorldMessagingInstrumenter(logMessage, contextLabel) {
  if (typeof chrome === "undefined" || !chrome || !chrome.runtime) return "no-chrome-runtime";
  if (chrome.runtime.__miniBrowserMsgInstrumented) return "already-installed";
  chrome.runtime.__miniBrowserMsgInstrumented = true;

  var extId = chrome.runtime.id || "unknown";

  function safeStringify(v) {
    try {
      var s = JSON.stringify(v);
      if (s === undefined) return String(v);
      return s.length > 300 ? s.slice(0, 300) + "…" : s;
    } catch (e) {
      return String(v);
    }
  }

  // Log every inbound message this context receives, and whether whatever
  // handled it ever actually called sendResponse.
  if (chrome.runtime.onMessage && typeof chrome.runtime.onMessage.addListener === "function") {
    var origAddListener = chrome.runtime.onMessage.addListener.bind(chrome.runtime.onMessage);
    chrome.runtime.onMessage.addListener = function (listener) {
      var wrapped = function (message, sender, sendResponse) {
        var callId = Math.random().toString(36).slice(2, 8);
        logMessage({ context: contextLabel, extId: extId, kind: "received", callId: callId, detail: safeStringify(message) });
        var responded = false;
        var wrappedSendResponse = function (resp) {
          responded = true;
          logMessage({ context: contextLabel, extId: extId, kind: "responded", callId: callId, detail: safeStringify(resp) });
          return sendResponse(resp);
        };
        var result;
        try {
          result = listener(message, sender, wrappedSendResponse);
        } catch (e) {
          logMessage({ context: contextLabel, extId: extId, kind: "listener-threw", callId: callId, detail: String((e && e.message) || e) });
          throw e;
        }
        if (result === true) {
          setTimeout(function () {
            if (!responded) {
              logMessage({ context: contextLabel, extId: extId, kind: "no-response", callId: callId, detail: "listener returned true (async) but never called sendResponse within 5s" });
            }
          }, 5000);
        }
        return result;
      };
      return origAddListener(wrapped);
    };
  }

  // Log every outbound sendMessage call this context makes, and whether it
  // ever got a reply — this is the one that actually shows a hung popup.
  if (typeof chrome.runtime.sendMessage === "function") {
    var origSendMessage = chrome.runtime.sendMessage.bind(chrome.runtime);
    chrome.runtime.sendMessage = function () {
      var args = Array.prototype.slice.call(arguments);
      var callId = Math.random().toString(36).slice(2, 8);
      var payload = args.filter(function (a) { return typeof a !== "function"; }).map(safeStringify).join(" | ");
      logMessage({ context: contextLabel, extId: extId, kind: "sent", callId: callId, detail: payload });

      var settled = false;
      var timer = setTimeout(function () {
        if (!settled) {
          logMessage({ context: contextLabel, extId: extId, kind: "no-reply", callId: callId, detail: "no response within 5s" });
        }
      }, 5000);

      var lastArg = args[args.length - 1];
      if (typeof lastArg === "function") {
        var origCb = lastArg;
        args[args.length - 1] = function (resp) {
          settled = true;
          clearTimeout(timer);
          logMessage({ context: contextLabel, extId: extId, kind: "reply", callId: callId, detail: safeStringify(resp) });
          return origCb.apply(this, arguments);
        };
        return origSendMessage.apply(null, args);
      }

      var maybePromise = origSendMessage.apply(null, args);
      if (maybePromise && typeof maybePromise.then === "function") {
        maybePromise.then(
          function (resp) {
            settled = true;
            clearTimeout(timer);
            logMessage({ context: contextLabel, extId: extId, kind: "reply", callId: callId, detail: safeStringify(resp) });
          },
          function (err) {
            settled = true;
            clearTimeout(timer);
            logMessage({ context: contextLabel, extId: extId, kind: "rejected", callId: callId, detail: String((err && err.message) || err) });
          }
        );
      }
      return maybePromise;
    };
  }

  return "installed";
}

  try {
    const result2 = contextBridge.executeInMainWorld({
      func: mainWorldMessagingInstrumenter,
      args: [logMessage, "extension-page"]
    });
    ipcRenderer.send("ext-msg-instrumentation-status", { context: "extension-page", result: result2 });
  } catch (err) {
    ipcRenderer.send("ext-msg-instrumentation-status", {
      context: "extension-page",
      result: "error",
      error: String((err && err.message) || err)
    });
  }
}
