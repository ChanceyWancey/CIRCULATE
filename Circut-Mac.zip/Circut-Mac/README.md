# Circut — macOS

A small Chromium-powered browser shell built with Electron.

## Requirements
- macOS
- Node.js installed
- Internet connection for the first dependency install

## Run it

Open Terminal and enter:

    cd "/path/to/Circut-Mac"
    npm install
    npm start

For example, if you put the folder on your Desktop:

    cd ~/Desktop/Circut-Mac
    npm install
    npm start

## Included
- Real Chromium web pages
- Tabs
- Address/search bar
- Back / forward / reload
- Bookmarks saved on your Mac
- History saved on your Mac
- Downloads to the normal Downloads folder
- Developer Tools
- New-tab links from pages

## Extensions
- Click the 🧩 button in the toolbar (or ⋯ → Extensions) to open the extensions panel.
- Three ways to install:
  - **📂 Load unpacked extension…** — pick a folder that already contains a `manifest.json`.
  - **📦 Add from .zip / .crx file…** — pick a downloaded extension package; it's extracted and loaded automatically.
  - **🔗 Add from URL** — paste a direct `.zip`/`.crx` link, a Chrome Web Store page URL, or a bare 32-letter extension ID, and Circut will download and install it.
- Real Chrome Web Store extensions work: pasting a store link or extension ID fetches the `.crx` from the same `clients2.google.com` update endpoint Chrome itself uses, converts it to a plain zip, and unpacks it. This relies on an undocumented-but-widely-used Google endpoint, so it can occasionally break if Google changes it — an official Chrome Web Store link is the most reliable input.
- Each installed extension gets a toggle switch (enable/disable) and a Remove button.
- Enabled extensions are remembered in `extensions.json` in the app's data folder and reloaded automatically the next time you launch Circut. Extensions installed via .zip/.crx/URL are extracted into that same data folder; removing them deletes the extracted copy too.
- Extensions with a toolbar action (`action`/`browser_action` in the manifest) get an icon next to the address bar; clicking it opens the extension's popup in its own window.
- Popups can be inspected with DevTools via the "Inspect popup" button in the panel. For Manifest V3 background service workers, the panel shows a best-effort running/idle status (full background-page DevTools aren't wired up yet).
- Content scripts run on normal web pages automatically, since all tabs share Electron's default session.
- Installing an extension gives it real access to the pages you visit — only install ones you trust.

### Note about extension compatibility
This is an Electron browser shell. Electron uses Chromium and has real (if partial) support for Manifest V3 extensions via `session.loadExtension()`, which is what powers the above — including genuine Chrome Web Store extensions, not just custom-built ones. It is not a full Google Chrome extension environment, though, so some Chrome-only APIs or UI (like a full `chrome://extensions` page) aren't present, and compatibility varies by extension. `unzip` (included by default on macOS) is used to extract downloaded packages.

This project is intended as a learning/browser-building project and does not implement bypasses for school/work network controls.
